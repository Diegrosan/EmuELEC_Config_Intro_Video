Anima��o criada em gif, foi eu mesmo que fiz.
Videos extraida da internet e algumas editada r�pida por me.

Animation created in gif, I did it myself.
Videos taken from the internet and some quick edited  by me.

Original Videos

Youtube channel: 4096
video:intro1
https://www.youtube.com/watch?v=mLq_P0K4jvA


Youtube channel: AD&MEDIA
video:intro2
https://www.youtube.com/watch?v=QOJHJrcZvDg

